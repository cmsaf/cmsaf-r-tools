library(testthat)
library(cmsafvis)

test_check("cmsafvis")
